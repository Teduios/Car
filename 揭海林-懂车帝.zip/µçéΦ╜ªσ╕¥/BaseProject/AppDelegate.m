//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "LeftViewController.h"
#import "WelcomeController.h"
#import "UMSocialQQHandler.h"
#import "UMSocial.h"
#define jiehailin  @"56444274e0f55a26d7000752"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [UMSocialData setAppKey:jiehailin];
    [UMSocialQQHandler setQQWithAppId:@"1104539912" appKey:@"eFVgRits2fqf36Jf" url:@"http://www.umeng.com/social"];
    
    [self initializeWithApplication:application];
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
     //NSLog(@"info %@",infoDic);
    NSString *key = @"CFBundleShortVersionString";
    NSString *currentVerson = infoDic[key];
    NSString *runVerson = [[NSUserDefaults standardUserDefaults] stringForKey:key];
    if(runVerson == nil ||![runVerson isEqualToString:currentVerson])
    {
        self.window.rootViewController = [WelcomeController new];
        [[NSUserDefaults standardUserDefaults] setValue:currentVerson forKey:key];
        [[UINavigationBar appearance]setTitleTextAttributes:@{NSFontAttributeName:[UIFont flatFontOfSize:20],NSForegroundColorAttributeName:kRGBColor(239, 141, 119)}];
    }else
    {
        self.window.rootViewController=self.sideMenu;
        [[UINavigationBar appearance]setTitleTextAttributes:@{NSFontAttributeName:[UIFont flatFontOfSize:20],NSForegroundColorAttributeName:kRGBColor(239, 141, 119)}];
    }
    
    
        return YES;
}
- (UIWindow *)window
{
    if(!_window)
    {
        _window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
    }
    return _window;
}
- (RESideMenu *)sideMenu
{
    if(!_sideMenu)
    {
        _sideMenu=[[RESideMenu alloc]initWithContentViewController:kVCFromSb(@"TabBarController", @"Main") leftMenuViewController:[LeftViewController new] rightMenuViewController:nil];
        _sideMenu.backgroundImage=[UIImage imageNamed:@"背景图"];
        _sideMenu.menuPrefersStatusBarHidden=YES;
        _sideMenu.bouncesHorizontally=NO;
    }
    return _sideMenu;
}
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    return  [UMSocialSnsService handleOpenURL:url];
}
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation
{
    return  [UMSocialSnsService handleOpenURL:url];
}

@end
